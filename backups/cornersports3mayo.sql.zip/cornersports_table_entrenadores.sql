
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenadores`
--

CREATE TABLE `entrenadores` (
  `id` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `especialidad` varchar(20) NOT NULL,
  `sueldo` decimal(10,0) NOT NULL,
  `puntuacion` int(2) NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `imagen_grande` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `entrenadores`
--

REPLACE INTO `entrenadores` (`id`, `nombre`, `especialidad`, `sueldo`, `puntuacion`, `imagen`, `descripcion`, `imagen_grande`) VALUES
(1, 'Jame Wilson', 'MUSCULACIÓN', '3400', 5, 'http://localhost/cornersports/img/entrenadores/wilson.jpg', 'James \"The Beast\" Wilson, uno de los kickboxer más conocidos mundialmente en la categoría de peso pesado.\r\nEn su explosiva clase en CYBEROBICS® desafiará con todas sus fuerzas a todo el que se atreva a enfrentarse él.', 'http://localhost/cornersports/img/entrenadores/wilson2.jpg'),
(2, 'Graham Labass', 'CARDIO', '2400', 4, 'http://localhost/cornersports/img/entrenadores/labass.jpg', 'Te hará sudar, te hará llorar - pero al final te llevará más lejos de lo que jamás habrías pensado. Súbete a la bici y deja que el \"Speed Star\" te enseñe el verdadero significado del cardio.', 'http://localhost/cornersports/img/entrenadores/labass2.jpg'),
(3, 'Trice Johnson', 'DEFINICIÓN', '1900', 3, 'http://localhost/cornersports/img/entrenadores/johnson.jpg', 'Trice lleva muchos años encima como entrenadora personal motivando a celebrities y a miles de fans a dar lo mejor de ellos mismos. Entrenate con ella para esculpir tu cuerpo.', 'http://localhost/cornersports/img/entrenadores/johnson2.jpg'),
(4, 'Briohny Smyth', 'YOGA', '2600', 4, 'http://localhost/cornersports/img/entrenadores/smyth.jpg', 'Como “Artist of Yoga” Briohny ha inspirado a millones de personas con sus fascinantes vídeos de fitness y espectaculares entrenamientos. Encuentra tú también tu equilibrio interior con esta estrella internacional del yoga.', 'http://localhost/cornersports/img/entrenadores/smyth2.jpg');
