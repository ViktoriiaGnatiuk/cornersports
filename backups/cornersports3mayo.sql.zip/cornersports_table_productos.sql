
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(8) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `tipo` varchar(12) NOT NULL,
  `precio_alquiler` float NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'en_carro',
  `pedido` int(8) NOT NULL,
  `cantidad` int(3) NOT NULL DEFAULT 1,
  `usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
