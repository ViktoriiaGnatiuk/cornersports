
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_disponibles`
--

CREATE TABLE `productos_disponibles` (
  `id` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `precio` float NOT NULL,
  `precio_alquiler` float NOT NULL,
  `descuento` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos_disponibles`
--

REPLACE INTO `productos_disponibles` (`id`, `nombre`, `tipo`, `imagen`, `descripcion`, `precio`, `precio_alquiler`, `descuento`) VALUES
(5, 'Mancuernas Barbaria 17.5kg', 'maquina', 'http://localhost/cornersports/img/productos/mancuernas1.jpg', 'Mancuernas Barbaria 17.5kg', 25.99, 6.85, NULL),
(6, 'Eliptica Bodytone DEE15', 'maquina', 'http://localhost/cornersports/img/productos/eliptica1.jpg', 'Eliptica Bodytone DEE15', 258.99, 24.99, 20),
(7, 'Guantes de boxeo Everlast M', 'deporte', 'http://localhost/cornersports/img/productos/guantes_boxeo1.jpg', 'Guantes de boxeo Everlast', 58.64, 15.65, NULL),
(8, 'Balón Fútbol Nike', 'deporte', 'http://localhost/cornersports/img/productos/pelota_futbol.jpg', 'Balón de fútbol Nike diseñado en color verde con detalles y logotipo en negro.', 15.99, 5.8, 15),
(9, 'Bate de beisbol KIPSTA', 'deporte', 'http://localhost/cornersports/img/productos/bate.jpg', 'Bate de béisbol de aleación de aluminio marca KIPSTA modelo BA150 34 pulgadas', 22, 8.59, NULL),
(10, 'Fitness Uniform Jum', 'prendaMujer', 'http://localhost/cornersports/img/productos/prendaMujer.jpg', 'Fitness Uniform Jum Talla M 100% Licra Conjunto completo', 35.99, 12.8, 22),
(11, 'Emporio Armani EA7', 'prendaHombre', 'http://localhost/cornersports/img/productos/prendaHombre.jpg', 'Emporio Armani EA7 chándal Poly Tricot júnior S. Conjunto de poliéster muy versátil.', 58.99, 12, NULL),
(12, 'Nike Revolution 38', 'prendaMujer', 'http://localhost/cornersports/img/productos/zapatillas.jpg', 'Disfruta de tus salidas de running o footing con las zapatillas para mujer Nike Revolution 5 talla 38.', 42.49, 8, 12);
