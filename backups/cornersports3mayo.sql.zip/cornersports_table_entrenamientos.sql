
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenamientos`
--

CREATE TABLE `entrenamientos` (
  `nombre` varchar(50) CHARACTER SET utf8 NOT NULL,
  `precio` float NOT NULL,
  `entrenador` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `dias` int(11) NOT NULL,
  `dificultad` varchar(10) CHARACTER SET utf8 NOT NULL,
  `dia_actual` int(2) NOT NULL,
  `fecha_comienzo` date NOT NULL DEFAULT current_timestamp(),
  `imagen` varchar(200) NOT NULL,
  `descripcion` varchar(500) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `entrenamientos`
--

REPLACE INTO `entrenamientos` (`nombre`, `precio`, `entrenador`, `id`, `dias`, `dificultad`, `dia_actual`, `fecha_comienzo`, `imagen`, `descripcion`) VALUES
('BOOTCAMP', 78, 1, 32, 28, 'ALTA', 0, '2020-05-03', 'http://localhost/cornersports/img/entrenamientos/musculacion.jpg', 'Este ejecutor te llevará hasta tu límite absoluto con intensos ejercicios de autocargas como los Prison Squads y Spiderman Push Ups.');
