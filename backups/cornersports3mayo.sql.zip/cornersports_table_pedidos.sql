
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(8) NOT NULL,
  `fecha` date NOT NULL DEFAULT current_timestamp(),
  `precio` float NOT NULL DEFAULT 0,
  `fecha_entrega` date DEFAULT NULL,
  `usuario` varchar(20) NOT NULL,
  `estado` varchar(12) NOT NULL DEFAULT 'SIN_TRAMITAR'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pedidos`
--

REPLACE INTO `pedidos` (`id`, `fecha`, `precio`, `fecha_entrega`, `usuario`, `estado`) VALUES
(103, '2020-05-03', 0, NULL, 'admin', 'SIN_TRAMITAR');
