
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenamientos_disponibles`
--

CREATE TABLE `entrenamientos_disponibles` (
  `id` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `dias` int(2) NOT NULL,
  `precio` int(2) NOT NULL,
  `entrenador` int(10) NOT NULL,
  `dificultad` varchar(10) NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `descripcion` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `entrenamientos_disponibles`
--

REPLACE INTO `entrenamientos_disponibles` (`id`, `nombre`, `dias`, `precio`, `entrenador`, `dificultad`, `imagen`, `descripcion`) VALUES
(2, 'Definición mujer', 30, 45, 3, 'ALTA', 'http://localhost/cornersports/img/entrenamientos/e2.jpg', 'Define tus musculos con nosotros.'),
(4, 'YOGA SPIRITS', 28, 54, 4, 'BAJA', 'http://localhost/cornersports/img/entrenamientos/yoga.jpg', 'Comienza tu entrenamiento el Saludo al Sol con 12 energéticas asanas que activarán tu cuerpo y tu espíritu. Junto a Briohny pondrás tu respiración y movimiento en armonía.'),
(5, 'BOOTCAMP', 28, 78, 1, 'ALTA', 'http://localhost/cornersports/img/entrenamientos/musculacion.jpg', 'Este ejecutor te llevará hasta tu límite absoluto con intensos ejercicios de autocargas como los Prison Squads y Spiderman Push Ups.'),
(10, 'Cardio en casa Coronavirus version', 30, 35, 2, 'MEDIA', 'http://localhost/cornersports/img/entrenamientos/e1.jpg', 'Entrena con nosotros desde tu casa ahora que no puedes salir.');
