
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="http://localhost/cornersports/estilos/estiloPie.css"/>
	</head>
	<body>
		<div class="mainPie">
			<h3 class ="pieText">Nuestros colaboradores</h3>
			<img  class="logo_pie" src="http://localhost/cornersports/img/logos/balance.jpg">
			<img class="logo_pie" src="http://localhost/cornersports/img/logos/fila.jpg">
			<img class="logo_pie" src="http://localhost/cornersports/img/logos/joma.png">
			<img class="logo_pie" src="http://localhost/cornersports/img/logos/lotto.jpg">
			<img class="logo_pie" src="http://localhost/cornersports/img/logos/nike.jpg">
			<img class="logo_pie" src="http://localhost/cornersports/img/logos/under.jpg">
			<img class="logo_pie" src="http://localhost/cornersports/img/logos/puma.jpg">
			<h3 class ="pieText2">CORNERSPORTS T.M.</h3>
		</div>
	</body>
	
</html>