<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <div id="popup" style="display:none;">
        <div class="content-popup">
            <div>
                <p class="pregunta">¿Estas seguro que quieres eliminar el producto?</p>
                <div class="inf_pop">
                    <input type="submit" class="confirmacion" value="Sí"/>
                    <input type="submit" class="negacion" value="No"/>
                </div>
                <div style="float:left; width:100%;"></div>
            </div>
        </div>
    </div>
    <div class="popup-overlay"></div>
</body>
</html>